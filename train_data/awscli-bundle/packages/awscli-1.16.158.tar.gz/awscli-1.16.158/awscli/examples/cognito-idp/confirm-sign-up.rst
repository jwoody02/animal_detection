**To confirm sign-up**

This example confirms sign-up for username diego@example.com. 

Command::

  aws cognito-idp confirm-sign-up --client-id 3n4b5urk1ft4fl3mg5e62d9ado --username=diego@example.com --confirmation-code CONF_CODE
 
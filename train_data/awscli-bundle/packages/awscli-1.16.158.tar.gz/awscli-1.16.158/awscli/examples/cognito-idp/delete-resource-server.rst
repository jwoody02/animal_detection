**To delete a resource server**

This example deletes a resource server named weather.example.com.

Command::

  aws cognito-idp delete-resource-server --user-pool-id us-west-2_aaaaaaaaa --identifier weather.example.com
  

**To enable a CloudWatch Events rule**

This example enables the rule named DailyLambdaFunction, which had been previously disabled::

  aws events enable-rule --name "DailyLambdaFunction"

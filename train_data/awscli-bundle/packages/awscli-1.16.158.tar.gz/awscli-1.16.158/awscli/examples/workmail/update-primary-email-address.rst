**To update a primary email address**

This example updates the primary email address of the specified entity (user, group, or resource).

Command::

  aws workmail update-primary-email-address --organization-id m-d281d0a2fd824be5b6cd3d3ce909fd27 --entity-id S-1-1-11-1111111111-2222222222-3333333333-3333 --email exampleUser2@site.awsapps.com

Output::

  None